package com.company.HumanitarianSchool;

import com.company.Teacher;

public class EnglishTeacher implements Teacher {
    @Override
    public void teach() {
        System.out.println("English teacher teaches English lessons");
    }
}
