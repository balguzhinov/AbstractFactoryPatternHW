package com.company.HumanitarianSchool;

import com.company.Tutor;

public class HumanitarianTutor implements Tutor {
    @Override
    public void prepare() {
        System.out.println("Tutor prepares for humanitarian subjects olympiad");
    }
}
