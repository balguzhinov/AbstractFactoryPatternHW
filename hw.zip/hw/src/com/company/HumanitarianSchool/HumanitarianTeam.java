package com.company.HumanitarianSchool;

import com.company.PrincipalSchool;
import com.company.SchoolFactory;
import com.company.Teacher;
import com.company.Tutor;

public class HumanitarianTeam implements SchoolFactory {
    @Override
    public PrincipalSchool getPrincipal() {
        return new HumanitarianPrincipal();
    }

    @Override
    public Teacher getTeacher() {
        return new EnglishTeacher();
    }

    @Override
    public Tutor getTutor() {
        return new HumanitarianTutor();
    }
}
