package com.company.HumanitarianSchool;

import com.company.PrincipalSchool;

public class HumanitarianPrincipal implements PrincipalSchool {
    @Override
    public void manage() {
        System.out.println("School Principal manages Liberal Arts School");
    }
}
