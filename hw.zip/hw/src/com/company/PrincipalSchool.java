package com.company;

public interface PrincipalSchool {
    void manage();
}
