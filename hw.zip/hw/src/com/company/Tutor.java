package com.company;

public interface Tutor {
    void prepare();
}
