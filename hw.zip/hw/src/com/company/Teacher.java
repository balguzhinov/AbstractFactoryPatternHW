package com.company;

public interface Teacher {
    void teach();
}
