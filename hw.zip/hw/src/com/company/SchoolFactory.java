package com.company;

public interface SchoolFactory {
    PrincipalSchool getPrincipal();
    Teacher getTeacher();
    Tutor getTutor();
}
