package com.company;

import com.company.TechnicianSchool.TechnicanSchool;

public class Main {

    public static void main(String[] args) {
        SchoolFactory schoolFactory = new TechnicanSchool();
        Teacher teacher = schoolFactory.getTeacher();
        PrincipalSchool principalSchool = schoolFactory.getPrincipal();
        Tutor tutor = schoolFactory.getTutor();

        System.out.println("This is the technical school...");
        teacher.teach();
        principalSchool.manage();
        tutor.prepare();



    }
}
