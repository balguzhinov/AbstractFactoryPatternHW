package com.company.TechnicianSchool;

import com.company.HumanitarianSchool.HumanitarianPrincipal;
import com.company.PrincipalSchool;
import com.company.SchoolFactory;
import com.company.Teacher;
import com.company.Tutor;

public class TechnicanSchool implements SchoolFactory {
    @Override
    public PrincipalSchool getPrincipal() {
        return new TechnicalPrincipal();
    }

    @Override
    public Teacher getTeacher() {
        return new MathTeacher();
    }

    @Override
    public Tutor getTutor() {
        return new TechnicalTutor();
    }
}
