package com.company.TechnicianSchool;

import com.company.PrincipalSchool;

public class TechnicalPrincipal implements PrincipalSchool {
    @Override
    public void manage() {
        System.out.println("School Principal managaes Technical School");
    }
}
