package com.company.TechnicianSchool;

import com.company.Tutor;

public class TechnicalTutor implements Tutor {
    @Override
    public void prepare() {
        System.out.println("Technical tutor prepare for physics/math olympiads");
    }
}
