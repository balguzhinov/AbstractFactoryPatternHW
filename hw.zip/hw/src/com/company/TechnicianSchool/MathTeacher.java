package com.company.TechnicianSchool;

import com.company.Teacher;

public class MathTeacher implements Teacher {
    @Override
    public void teach() {
        System.out.println("Teacher teaches math to the students");
    }
}
